drop table if exists plugins.empenhocotamensalanulacao;
